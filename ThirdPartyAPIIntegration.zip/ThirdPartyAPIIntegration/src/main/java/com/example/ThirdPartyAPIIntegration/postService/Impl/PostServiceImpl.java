package com.example.ThirdPartyAPIIntegration.postService.Impl;

import com.example.ThirdPartyAPIIntegration.model.Posts;
import com.example.ThirdPartyAPIIntegration.postService.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Service
public class PostServiceImpl implements PostService {

    String baseUrl = "https://jsonplaceholder.typicode.com/";
    StringBuilder str = new StringBuilder(baseUrl);

    String POST =  "/posts";

    String POSTBYID ="/posts/";

    @Autowired
    private RestTemplate restTemplate;

    @Override
    public List<Map<String,Object>> getPost() {

////        HttpEntity<Void> httpEntity = new HttpEntity<>(getHttpHeaders());
////        String url = str.append(POST).toString();
//        String url = str + POST ;
//////        ResponseEntity<Posts> posts = restTemplate.exchange(url,HttpMethod.GET,httpEntity,Posts.class);
//////        return new ResponseEntity<> (List.of(posts),HttpStatus.OK);
////        Posts[] posts = restTemplate.getForObject(url,Posts[].class);
//////        val posts = restTemplate.exchange(url,HttpMethod.GET,httpEntity,List.class);
////
////        assert posts != null;
////        return new ResponseEntity<>(List.of(posts),HttpStatus.OK);
//        Posts[] posts = restTemplate.getForObject(url,Posts[].class);
//        assert posts !=null;
//        return new ResponseEntity<>(Arrays.asList(posts),HttpStatus.OK);

        try {
            HttpEntity<Void> httpEntity = new HttpEntity<>(getHttpHeaders());
            String url = str + POST;
            ResponseEntity<List<Map<String,Object>>> response = restTemplate.exchange(url,HttpMethod.GET,httpEntity,ParameterizedTypeReference.forType(List.class));
            if(response.getStatusCode().is2xxSuccessful())
                    return response.getBody();


        }
        catch (Exception ex){
            System.out.println(ex);
        }

        return null;
    }

    @Override
    public Map<String,Object> getPostById(Integer id) {

        try{
            HttpEntity<Void> httpEntity = new HttpEntity<Void>(getHttpHeaders());
//            String url = str.append(POSTBYID).append(id).toString();
            String url = str + POSTBYID + id;
            System.out.println(url);
//            Posts post = restTemplate.getForObject(url,Posts.class);
            ResponseEntity<Map<String,Object>> post = restTemplate.exchange(url,HttpMethod.GET,httpEntity, ParameterizedTypeReference.forType(Map.class));
            System.out.println(post);
            if(post.getStatusCode().is2xxSuccessful()){
                return post.getBody();
            }
        }catch (Exception ignored){
            System.out.println(ignored);
        }

    return  null;
    }

    @Override
    public Map<String, Object> insertPost(Map<String, Object> payLoad) {
        try{
            HttpEntity<Map<String, Object>> httpEntity = new HttpEntity<>(payLoad,getHttpHeaders());
            String url = str + POST;
            ResponseEntity<Map<String, Object>> response = restTemplate.exchange(url,HttpMethod.POST,httpEntity, ParameterizedTypeReference.forType(Map.class));
            System.out.println(response);
            if(response.getStatusCode().is2xxSuccessful())
                    return response.getBody();
        }catch (Exception ex){
            System.out.println(ex);
        }

        return null;
    }

    @Override
    public Map<String, Object> updatePost(Map<String, Object> payLoad, Integer id) {
        try{
            HttpEntity<Map<String, Object>> httpEntity = new HttpEntity<>(payLoad,getHttpHeaders());
            String url = str + POSTBYID;
            ResponseEntity<Map<String, Object>> response = restTemplate.exchange(url,HttpMethod.PUT,httpEntity,ParameterizedTypeReference.forType(Map.class));
            System.out.println(response);
            if(response.getStatusCode().is2xxSuccessful())
                    return response.getBody();
        }catch (Exception exp){
            System.out.println(exp);
        }
        return  null;
    }

    @Override
    public Map<String, Object> deletePost(Integer id) {
        try {
            HttpEntity<Void> httpEntity = new HttpEntity<>(getHttpHeaders());
            String url = str + POSTBYID;
            ResponseEntity<Map<String, Object>> response = restTemplate.exchange(url,HttpMethod.DELETE,httpEntity,ParameterizedTypeReference.forType(Map.class));
            System.out.println(response);
            if (response.getStatusCode().is2xxSuccessful())
                    return response.getBody();

        }
        catch (Exception ex){
            System.out.println(ex);
        }

        return null;
    }

    private HttpHeaders getHttpHeaders(){

        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(List.of(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        return headers;
    }
}
