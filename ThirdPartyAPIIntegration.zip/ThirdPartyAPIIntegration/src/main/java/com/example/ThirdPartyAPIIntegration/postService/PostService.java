package com.example.ThirdPartyAPIIntegration.postService;

import jakarta.persistence.criteria.CriteriaBuilder;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Map;
import java.util.Objects;

public interface PostService {

    List<Map<String,Object>> getPost();

    Map<String,Object> getPostById(Integer id);

    Map<String,Object> insertPost(Map<String,Object> payLoad);

    Map<String,Object> updatePost(Map<String,Object> payLoad,Integer id);

    Map<String,Object> deletePost(Integer id);
}


